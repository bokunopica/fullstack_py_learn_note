# Django


## SQLite
- 轻量级的嵌入式级的数据库
- 特点是小
    - 常用场景
    - Android，IOS，WP
- 数据库常规操作相似度和MySQL达百分之九十五

## 播放器
- 完美解码
- 加速播放
    - 音视频同步加速
    
## 快捷键
- 万能键
    - alt + enter 
    
## 实现一个请求
- 注册一个路由
    - urls中
        - url
            - 参数①  匹配规则  正则
        - 视图函数
            - 对应的是views中的一个函数
                - 没有括号
- 去views实现对应的视图函数
    - 第一个参数是request
    - 永远记得返回Response
    
## html
- ul>li
- ul*5 
- ul>li*5


## 模板配置
- 两种
    - 在App中进行模板配置
    - 只需在App的根目录创建templates文件夹即可
