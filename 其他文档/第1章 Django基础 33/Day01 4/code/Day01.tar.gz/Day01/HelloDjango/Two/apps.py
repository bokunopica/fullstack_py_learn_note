from django.apps import AppConfig


class TwoConfig(AppConfig):
    name = 'Two'
