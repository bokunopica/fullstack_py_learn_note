from django.apps import AppConfig


class ThreeConfig(AppConfig):
    name = 'Three'
